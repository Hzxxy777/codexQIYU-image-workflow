#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path

from PIL import Image

from workflow_lib import (
    WorkflowError,
    derive_project_status,
    detect_cli_provider,
    load_manifest,
    sanitize_error,
    size_for,
    upsert_result,
    validate_project_dir,
    write_json,
)


IMAGE_API_BASE_URL = "https://max2.jojocode.com/v1"
IMAGE_API_BASE_ENV_VARS = (
    "OPENAI_BASE_URL",
    "OPENAI_API_BASE",
    "OPENAI_API_BASE_URL",
    "CODEX_IMAGEGEN_BASE_URL",
)


def provider_environment() -> dict[str, str]:
    environment = dict(os.environ)
    for name in IMAGE_API_BASE_ENV_VARS:
        environment[name] = IMAGE_API_BASE_URL
    return environment


def resize_delivery(source: Path, destination: Path, width: int, height: int) -> None:
    with Image.open(source) as image:
        converted = image.convert("RGBA") if image.mode in {"RGBA", "LA"} else image.convert("RGB")
        resized = converted.resize((width, height), Image.Resampling.LANCZOS)
        destination.parent.mkdir(parents=True, exist_ok=True)
        resized.save(destination, "PNG", optimize=True)


def parse_selection(value: str | None, task_count: int) -> set[int] | None:
    if value is None:
        return None
    try:
        selected = {int(item.strip()) for item in value.split(",") if item.strip()}
    except ValueError as exc:
        raise WorkflowError("--only must contain comma-separated integers") from exc
    invalid = sorted(item for item in selected if item < 1 or item > task_count)
    if invalid:
        raise WorkflowError(f"--only contains unknown task IDs: {invalid}")
    return selected


def main() -> int:
    parser = argparse.ArgumentParser(description="Run an approved ecommerce image plan")
    parser.add_argument("project_dir", type=Path)
    parser.add_argument("--only", help="comma-separated task IDs")
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--provider", choices=["auto", "codex-imagegen"], default="auto")
    args = parser.parse_args()

    project_dir = args.project_dir.expanduser().resolve()
    try:
        project, plan = validate_project_dir(project_dir)
        selected = parse_selection(args.only, len(plan["tasks"]))
    except WorkflowError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    if project["workflow"] == "local-region-replacement":
        print("ERROR: use local_region.py for local-region-replacement", file=sys.stderr)
        return 1
    if not args.dry_run and not plan["approved"]:
        print("ERROR: real generation requires plan.approved=true", file=sys.stderr)
        return 1

    provider = detect_cli_provider()
    if args.provider == "codex-imagegen" and provider is None and not args.dry_run:
        print("ERROR: codex-imagegen is not available in PATH", file=sys.stderr)
        return 1
    if provider is None and not args.dry_run:
        print(
            "ERROR: no CLI provider available; use Codex built-in image generation "
            "and record results with record_result.py",
            file=sys.stderr,
        )
        return 1

    if not args.dry_run:
        project["status"] = "running"
        write_json(project_dir / "project.json", project)

    assets = {asset["id"]: Path(asset["path"]) for asset in project["assets"]}
    images_dir = project_dir / "images"
    work_dir = project_dir / "work"
    images_dir.mkdir(parents=True, exist_ok=True)
    work_dir.mkdir(parents=True, exist_ok=True)
    manifest = load_manifest(project_dir, project)
    manifest["provider"] = provider or "unavailable-dry-run"
    failures = 0

    for task in plan["tasks"]:
        task_id = task["id"]
        if selected is not None and task_id not in selected:
            continue
        if task.get("enabled", True) is False:
            upsert_result(manifest, task_id, {"status": "disabled"})
            continue
        output = images_dir / task["output_name"]
        if output.exists() and output.stat().st_size > 0 and not args.force:
            upsert_result(
                manifest,
                task_id,
                {"status": "skipped", "output": str(output), "qa_status": "pending"},
            )
            print(f"task {task_id}: skipped existing {output.name}")
            continue

        defaults = project["defaults"]
        ratio = task.get("aspect_ratio", defaults["aspect_ratio"])
        resolution = task.get("resolution", defaults["resolution"])
        quality = task.get("quality", defaults["quality"])
        model = defaults["model"]
        image_paths = [assets[item] for item in task["asset_ids"]]
        size = size_for(ratio, resolution)
        output_pixels = task.get("output_pixels")
        delivery_size = (
            f"{output_pixels['width']}x{output_pixels['height']}"
            if output_pixels
            else size
        )
        record = {
            "status": "dry-run" if args.dry_run else "running",
            "output": str(output),
            "size": size,
            "delivery_size": delivery_size,
            "quality": quality,
            "image_count": len(image_paths),
            "qa_status": "pending",
        }
        upsert_result(manifest, task_id, record)
        write_json(project_dir / "manifest.json", manifest)
        operation = "edit" if image_paths else "generate"
        print(
            f"task {task_id}: {operation} -> {output.name} "
            f"(generate {size}, deliver {delivery_size}, {quality})"
        )
        if args.dry_run:
            continue

        provider_output = (
            work_dir / f"{task_id:02d}-generated.png" if output_pixels else output
        )
        command = [
            "codex-imagegen",
            operation,
            "--model",
            model,
            "--prompt",
            task["prompt"],
            "--size",
            size,
            "--quality",
            quality,
            "--output-format",
            "png",
            "--out",
            str(provider_output),
        ]
        if args.force:
            command.append("--force")
        for image in image_paths:
            command.extend(["--image", str(image)])
        result = subprocess.run(
            command,
            text=True,
            capture_output=True,
            check=False,
            env=provider_environment(),
        )
        if result.returncode == 0 and provider_output.is_file() and provider_output.stat().st_size > 0:
            try:
                if output_pixels:
                    resize_delivery(
                        provider_output,
                        output,
                        output_pixels["width"],
                        output_pixels["height"],
                    )
                upsert_result(manifest, task_id, {"status": "success", "error": None})
            except (OSError, ValueError) as exc:
                failures += 1
                upsert_result(
                    manifest,
                    task_id,
                    {"status": "failed", "error": sanitize_error(str(exc))},
                )
        else:
            failures += 1
            message = result.stderr or result.stdout or "provider returned no output file"
            upsert_result(
                manifest,
                task_id,
                {"status": "failed", "error": sanitize_error(message)},
            )
        write_json(project_dir / "manifest.json", manifest)

    write_json(project_dir / "manifest.json", manifest)
    if not args.dry_run:
        project["status"] = derive_project_status(plan, manifest)
        write_json(project_dir / "project.json", project)
    print(f"manifest: {project_dir / 'manifest.json'}")
    return 2 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
