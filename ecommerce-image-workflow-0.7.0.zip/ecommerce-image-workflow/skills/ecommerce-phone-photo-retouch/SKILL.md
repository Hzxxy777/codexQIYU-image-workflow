---
name: ecommerce-phone-photo-retouch
description: >-
  引导用户上传同一商品不同面的 1-5 张普通手机照片，综合锁定商品事实后逐张自动精修，重点改善真实材质质感、光泽、微纹理、边缘、曝光、白平衡、透视、噪点、灰尘、背景和反光。用户提到手机拍摄商品图精修、随手拍变电商图、自动修商品照片、提升产品质感或影棚级优化时使用。创建新场景、复刻参考图、只改局部区域或批量改画幅时不要使用本技能。
---

# 手机商品照片自动精修

## 生图 API 配置

真实生图默认使用 `https://max2.jojocode.com/v1` 作为 API base URL。执行公共 `run_plan.py` 或本地 `codex-imagegen` 时，必须按公共 `references/image-api-config.md` 注入 `OPENAI_BASE_URL`、`OPENAI_API_BASE`、`OPENAI_API_BASE_URL` 和 `CODEX_IMAGEGEN_BASE_URL`。除非用户明确要求，否则不要绕过这套配置调用其他生图入口。

保持内联执行，不使用子代理，不创建素材投递文件夹。开始读取 `references/execution-modes.md`；未指定模式先询问快速/专业。快速模式展示提示词和计划后直接并发生成，专业模式等待确认。多张照片用 `run_plan.py --concurrency auto` 一次并发，首轮完成后集中 QA，只并发重画失败项。

## 素材引导

先请用户直接在对话中上传同一商品不同面的 1-5 张手机照片。根据商品特点优先选择正面、背面、左右侧面、顶部/底部、Logo/标签、接口或功能细节、材质纹理、包装与配件中最有信息量的角度。商品结构简单时不强求凑齐五张；已有照片不重复索取。

要求尽量使用原图，不要先加滤镜、截图或压缩。不同 SKU 不要混在同一批；多个 SKU 转到批量 SKU 或分项目处理。

## 自动诊断

先综合所有角度建立一份商品事实表，再逐张检查曝光、动态范围、白平衡、偏色、透视、水平线、镜头畸变、噪点、压缩痕迹、对焦清晰度、灰尘污点、背景干扰、阴影、反光、材质表现和裁切空间。把问题分为：可安全修复、需要生成式重建、无法从照片确认。

同时登记不可改动的商品事实：外形与比例、部件位置、颜色、材质、表面纹理、光泽类型、Logo、标签文字、包装、接口、按钮、配件数量和任何不对称细节。看不清的事实标记为不确定，不猜测或补造。

材质诊断必须区分并描述真实的光学表现，例如：哑光塑料的细腻漫反射、亮面塑料的受控高光、拉丝金属的方向性纹理、抛光金属的干净反射、玻璃的透光与边缘高光、皮革或织物的细微纹理、木材的自然纹路。只使用照片可见或用户确认的材质事实。

## 精修档位

每次用户提出产品精修需求时，必须在首次回复中展示以下三个档位并要求用户选择；不得自行默认档位。可根据照片问题给出推荐，但仍须等待用户确认。

1. `natural` 自然修复：只修曝光、色温、噪点、轻微透视、灰尘和清晰度，保留真实拍摄环境与自然质感。
2. `ecommerce` 标准电商精修：在自然修复基础上整理背景、优化光影层次和商品边缘，使画面达到干净专业的电商成片水平，但不更换场景或重设计商品。
3. `studio` 影棚升级：重建为可信的商业影棚光线和干净背景，同时保持原构图意图和全部商品事实。若用户要求新场景或营销创意，转到快捷生成。

默认保持原始画幅、主体位置、可见文字和商品数量。裁切、移除道具、更换背景颜色、删除阴影或大幅改变构图必须单独列出并获得确认。

## 计划与确认

1. 定位插件根目录，读取公共项目 schema、`gpt-image-2-prompt-optimizer.md` 和质检规则。
2. 先发送内置客户话术，展示逐图诊断、商品事实和不确定项；必须收集并确认输出图片比例、输出分辨率（`2K` 或 `4K`）和精修档位（`natural`、`ecommerce` 或 `studio`）。信息不完整时不得创建生成计划。
3. 创建 `phone-photo-retouch` 项目，每张输入照片登记为一个 `product` asset，并严格创建一个对应任务。每个任务中 Image 1 是当前待精修照片；其余角度按确认顺序作为商品结构、颜色、材质、Logo 和文字核验参考，不提供当前画面的构图或可见内容。
4. 把用户要求和确认后的诊断保存为 `original_request`。使用下方内置精修提示词模块生成 `precise-object-edit` 或 `identity-preserve` 提示词，分别写明允许修改项和不可修改项。
5. 展示每张图的原需求、优化提示词、Image 1 映射、修复清单和不变量，请用户批准或提出单点修改。未批准任务保持 `pending`。
6. 所有启用任务提示词批准后，展示任务数、逐图精修目标、用户指定的图片比例、`2K` 或 `4K` 分辨率、精修档位、输出名和目录，等待完整计划确认。未指定比例、分辨率或档位时不得生成。
7. 用户明确确认完整计划，且已指定图片比例、分辨率和精修档位后，才设置 `plan.approved=true` 并生成。优先使用 Codex 内置图片能力，否则调用公共 `run_plan.py`。

## 质检与重做

逐张对比原图，检查商品几何结构、颜色、Logo、标签文字、配件数量和原始画幅是否保持；同时检查曝光、白平衡、透视、噪点、边缘、背景、反光和清晰度是否改善。任何商品事实漂移都判定为失败。

只对失败图片重做，并把失败原因改写为一个针对性的修正要求。不得覆盖原始手机照片；最终结果和 QA 记录保存到标准项目目录。

## 内置质感精修提示词

每次收到产品精修需求时，首次回复必须发送以下客户话术。只有用户指定图片比例、`2K` 或 `4K` 分辨率及精修档位后，才能进入生成计划：

```text
您好，这边可以为您上传的实拍原图做 AI 产品精修。请确认以下三项：

1. 图片比例：例如 `1:1`、`4:5`、`3:4`、`16:9`，或保持原图比例。
2. 输出分辨率：`2K` 或 `4K`。
3. 精修档位：
   - `natural` 自然修复：修正曝光、色温、噪点、轻微透视、灰尘和清晰度，保留原始拍摄环境与自然质感。
   - `ecommerce` 标准电商精修：在自然修复基础上整理背景、优化光影层次和商品边缘，不更换场景或重设计商品。
   - `studio` 影棚升级：重建可信的商业影棚光线和干净背景，同时保持原构图意图和全部商品事实。

请直接回复：`图片比例 + 分辨率 + 精修档位`。例如：`1:1，4K，ecommerce`。
```

将 `<resolution>` 和 `<retouch_level>` 替换为用户确认值。提示词必须完整包含以下模块；不得把 `natural` 或 `ecommerce` 强行改成白底：

```text
Use case: precise-object-edit
Asset type: premium ecommerce product photo retouch
Output resolution: <resolution> ultra-high-definition final image
Retouch level: <retouch_level>

Primary request: Automatically identify the product and preserve its exact structure, proportions, silhouette, component construction, true base color, material identity, surface micro-texture, workmanship, logos, label spelling, packaging, ports, controls, and accessory count. Improve tactile realism: recover fine grain, weave, brushed direction, controlled gloss, believable translucency, clean specular highlights, soft tonal transitions, and physically coherent contact edges. Correct casual-phone exposure, white balance, color cast, lens distortion, noise, compression, dust, distracting reflections, blur, and uneven focus without plastic-looking over-smoothing.

Level module:
- natural: preserve the original environment, composition, shadows, and background; repair only photographic defects and lightly improve material clarity.
- ecommerce: preserve the scene identity while cleaning the background, organizing light and edge separation, and improving product readability for a listing; do not redesign the product or invent a new setting.
- studio: preserve all product facts and the original composition intent, but permit a credible studio light rebuild and clean background; use restrained, realistic shadows and reflections only when physically appropriate.

Finish: premium but truthful commercial photography, crisp edges without halos, accurate color, realistic material response, no waxy skin-like smoothing, no fake 3D rendering, no oversharpening, and no loss of tiny manufacturing details.

Constraints: preserve exact product identity, geometry, visible parts, component placement, product count, colors, materials, logos, label spelling, packaging, ports, controls, accessories, and all confirmed facts. Do not invent hidden details, alter text, or redesign the product. The current target photo (Image 1) controls composition and visible content; cross-angle images are fact-only references.

Negative prompt (mandatory): invented parts, altered logo, misspelled text, extra product, missing accessory, plastic texture, waxy smoothing, fake CGI, over-sharpening, halos, white fringe, clipped highlights, crushed shadows, banding, chromatic aberration, heavy HDR, color cast, blur, noise, dust, fingers, person, watermark, unsupported claim, collage, border, accidental crop.
```
