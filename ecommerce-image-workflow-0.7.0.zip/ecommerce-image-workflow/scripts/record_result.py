#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import struct
import sys
import tempfile
import zlib
from pathlib import Path

from workflow_lib import (
    WorkflowError,
    build_trace_value,
    derive_project_status,
    load_manifest,
    sanitize_error,
    state_lock,
    upsert_result,
    validate_project_dir,
    write_json,
)


RESULT_STATUSES = {
    "queued",
    "running",
    "generated-awaiting-qa",
    "success",
    "qa-pass",
    "retry-queued",
    "failed",
    "failed-after-retries",
    "skipped",
    "cancelled",
}

PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"
TRACE_KEYWORD = b"workflow.ref"


def _png_chunk(chunk_type: bytes, data: bytes) -> bytes:
    checksum = zlib.crc32(chunk_type + data) & 0xFFFFFFFF
    return struct.pack(">I", len(data)) + chunk_type + data + struct.pack(">I", checksum)


def stamp_png_trace(path: Path) -> None:
    raw = path.read_bytes()
    if not raw.startswith(PNG_SIGNATURE):
        raise WorkflowError(f"final output is not a PNG file: {path}")

    trace_data = TRACE_KEYWORD + b"\0\0\0\0\0" + build_trace_value().encode("utf-8")
    trace_chunk = _png_chunk(b"iTXt", trace_data)
    output = bytearray(PNG_SIGNATURE)
    position = len(PNG_SIGNATURE)
    inserted = False
    while position < len(raw):
        if position + 12 > len(raw):
            raise WorkflowError(f"invalid PNG chunk structure: {path}")
        length = struct.unpack(">I", raw[position : position + 4])[0]
        end = position + 12 + length
        if end > len(raw):
            raise WorkflowError(f"truncated PNG chunk: {path}")
        chunk_type = raw[position + 4 : position + 8]
        chunk_data = raw[position + 8 : position + 8 + length]
        is_existing_trace = (
            chunk_type == b"iTXt" and chunk_data.split(b"\0", 1)[0] == TRACE_KEYWORD
        )
        if chunk_type == b"IEND" and not inserted:
            output.extend(trace_chunk)
            inserted = True
        if not is_existing_trace:
            output.extend(raw[position:end])
        position = end

    if not inserted or position != len(raw):
        raise WorkflowError(f"invalid PNG terminator: {path}")

    fd, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=str(path.parent)
    )
    temporary = Path(temporary_name)
    try:
        with os.fdopen(fd, "wb") as writer:
            writer.write(output)
            writer.flush()
            os.fsync(writer.fileno())
        os.chmod(temporary, path.stat().st_mode)
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def publish_output(source: Path, destination: Path, *, force: bool) -> None:
    if not source.is_file() or source.stat().st_size == 0:
        raise WorkflowError("successful output must be a non-empty file")
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists() and not force:
        raise WorkflowError(
            f"final output already exists: {destination}; use --force to replace it"
        )
    fd, temporary_name = tempfile.mkstemp(
        prefix=f".{destination.name}.", suffix=".tmp", dir=str(destination.parent)
    )
    temporary = Path(temporary_name)
    try:
        with source.open("rb") as reader, os.fdopen(fd, "wb") as writer:
            while chunk := reader.read(1024 * 1024):
                writer.write(chunk)
            writer.flush()
            os.fsync(writer.fileno())
        os.replace(temporary, destination)
    finally:
        temporary.unlink(missing_ok=True)


def main() -> int:
    parser = argparse.ArgumentParser(description="Record a built-in provider result or QA review")
    parser.add_argument("project_dir", type=Path)
    parser.add_argument("--task", required=True, type=int)
    parser.add_argument(
        "--status", choices=sorted(RESULT_STATUSES)
    )
    parser.add_argument("--output", type=Path)
    parser.add_argument("--provider", default="codex-builtin-imagegen")
    parser.add_argument("--error")
    parser.add_argument("--qa", choices=["pending", "pass", "fail"])
    parser.add_argument("--notes")
    parser.add_argument("--qa-round", type=int, default=0)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    project_dir = args.project_dir.expanduser().resolve()
    try:
        project, plan = validate_project_dir(project_dir)
    except WorkflowError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    if args.task < 1 or args.task > len(plan["tasks"]):
        print("ERROR: unknown task ID", file=sys.stderr)
        return 1
    if args.status in {"queued", "running", "generated-awaiting-qa", "qa-pass"} and not plan["approved"]:
        print("ERROR: image generation results require plan.approved=true", file=sys.stderr)
        return 1
    if args.qa_round < 0:
        print("ERROR: --qa-round must be non-negative", file=sys.stderr)
        return 1
    values: dict[str, object] = {}
    if args.status:
        values["status"] = args.status
    if args.output:
        output = args.output.expanduser().resolve()
        if args.status in {"generated-awaiting-qa", "qa-pass"} and (
            not output.is_file() or output.stat().st_size == 0
        ):
            print("ERROR: successful output must be a non-empty file", file=sys.stderr)
            return 1
        values["output"] = str(output)
    if args.error:
        values["error"] = sanitize_error(args.error)
    if args.qa:
        values["qa_status"] = args.qa
        values["qa_round"] = args.qa_round
    if args.notes is not None:
        values["qa_notes"] = args.notes
    if not values:
        print("ERROR: provide a status, output, error, QA status, or notes", file=sys.stderr)
        return 1

    task = plan["tasks"][args.task - 1]
    with state_lock(project_dir):
        project, plan = validate_project_dir(project_dir)
        manifest = load_manifest(project_dir, project)
        existing = next(
            (item for item in manifest.get("results", []) if item.get("task_id") == args.task),
            {},
        )
        output = Path(str(values.get("output", existing.get("output", "")))).expanduser()
        qa_pass = args.qa == "pass" or args.status == "qa-pass"
        if qa_pass:
            if not output.is_absolute():
                print("ERROR: QA pass requires a staged output path", file=sys.stderr)
                return 1
            final_output = project_dir / "images" / task["output_name"]
            try:
                if output.resolve() != final_output.resolve():
                    publish_output(output.resolve(), final_output, force=args.force)
                elif not output.is_file() or output.stat().st_size == 0:
                    raise WorkflowError("successful output must be a non-empty file")
                stamp_png_trace(final_output)
            except WorkflowError as exc:
                print(f"ERROR: {exc}", file=sys.stderr)
                return 1
            values.update(
                {
                    "status": "qa-pass",
                    "qa_status": "pass",
                    "output": str(final_output),
                    "staged_output": str(output.resolve()),
                }
            )
        elif args.qa == "fail":
            values["status"] = "retry-queued"
        elif args.status == "success":
            values["status"] = "generated-awaiting-qa"
        manifest["provider"] = args.provider
        upsert_result(manifest, args.task, values)
        write_json(project_dir / "manifest.json", manifest)
        project["status"] = derive_project_status(plan, manifest)
        write_json(project_dir / "project.json", project)
    print(f"recorded task {args.task}: {project_dir / 'manifest.json'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
