#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import random
import re
import signal
import subprocess
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from contextlib import nullcontext
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from PIL import Image

from workflow_lib import (
    WorkflowError,
    derive_project_status,
    detect_cli_provider,
    load_manifest,
    run_lock,
    sanitize_error,
    size_for,
    state_lock,
    upsert_result,
    validate_project_dir,
    write_json,
)


IMAGE_API_BASE_URL = "https://max2.jojocode.com/v1"
IMAGE_API_BASE_ENV_VARS = (
    "OPENAI_BASE_URL",
    "OPENAI_API_BASE",
    "OPENAI_API_BASE_URL",
    "CODEX_IMAGEGEN_BASE_URL",
)
TRANSIENT_MARKERS = (
    "408",
    "425",
    "429",
    "500",
    "502",
    "503",
    "504",
    "rate limit",
    "too many requests",
    "timeout",
    "timed out",
    "temporarily unavailable",
    "connection reset",
    "connection aborted",
)


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def provider_environment() -> dict[str, str]:
    environment = dict(os.environ)
    for name in IMAGE_API_BASE_ENV_VARS:
        environment[name] = IMAGE_API_BASE_URL
    return environment


def resize_delivery(source: Path, destination: Path, width: int, height: int) -> None:
    with Image.open(source) as image:
        converted = image.convert("RGBA") if image.mode in {"RGBA", "LA"} else image.convert("RGB")
        resized = converted.resize((width, height), Image.Resampling.LANCZOS)
        destination.parent.mkdir(parents=True, exist_ok=True)
        resized.save(destination, "PNG", optimize=True)


def validate_image(path: Path, expected_size: tuple[int, int] | None = None) -> tuple[int, int]:
    if not path.is_file() or path.stat().st_size == 0:
        raise WorkflowError(f"provider returned no output file: {path}")
    try:
        with Image.open(path) as image:
            image.verify()
        with Image.open(path) as image:
            actual = image.size
    except OSError as exc:
        raise WorkflowError(f"generated output is not a decodable image: {path}") from exc
    if expected_size is not None and actual != expected_size:
        raise WorkflowError(
            f"generated output dimensions are {actual[0]}x{actual[1]}, expected "
            f"{expected_size[0]}x{expected_size[1]}"
        )
    return actual


def parse_selection(value: str | None, task_count: int) -> set[int] | None:
    if value is None:
        return None
    try:
        selected = {int(item.strip()) for item in value.split(",") if item.strip()}
    except ValueError as exc:
        raise WorkflowError("--only must contain comma-separated integers") from exc
    invalid = sorted(item for item in selected if item < 1 or item > task_count)
    if invalid:
        raise WorkflowError(f"--only contains unknown task IDs: {invalid}")
    return selected


def resolve_concurrency(value: str, pending_count: int, max_concurrency: int) -> int:
    if not 1 <= max_concurrency <= 20:
        raise WorkflowError("--max-concurrency must be between 1 and 20")
    if value == "auto":
        return max(1, min(pending_count or 1, max_concurrency))
    try:
        concurrency = int(value)
    except ValueError as exc:
        raise WorkflowError("--concurrency must be auto or an integer") from exc
    if not 1 <= concurrency <= 20:
        raise WorkflowError("--concurrency must be between 1 and 20")
    return max(1, min(concurrency, pending_count or 1))


def retry_after_seconds(message: str) -> float | None:
    match = re.search(r"retry[- ]after[:= ]+([0-9]+(?:\.[0-9]+)?)", message, re.I)
    return float(match.group(1)) if match else None


def is_transient_failure(message: str) -> bool:
    lowered = message.lower()
    return any(marker in lowered for marker in TRANSIENT_MARKERS)


def is_rate_limited(message: str) -> bool:
    lowered = message.lower()
    return "429" in lowered or "rate limit" in lowered or "too many requests" in lowered


@dataclass
class TaskResult:
    task_id: int
    values: dict[str, Any]
    rate_limited: bool = False
    retry_after: float | None = None


class ProcessRegistry:
    def __init__(self) -> None:
        self.cancelled = threading.Event()
        self._lock = threading.Lock()
        self._processes: set[subprocess.Popen[str]] = set()

    def add(self, process: subprocess.Popen[str]) -> None:
        with self._lock:
            self._processes.add(process)

    def remove(self, process: subprocess.Popen[str]) -> None:
        with self._lock:
            self._processes.discard(process)

    def cancel(self) -> None:
        self.cancelled.set()
        with self._lock:
            processes = list(self._processes)
        for process in processes:
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except (ProcessLookupError, PermissionError):
                continue


def execute_process(
    command: list[str], *, timeout: int, registry: ProcessRegistry
) -> tuple[int, str, str, bool]:
    if registry.cancelled.is_set():
        return 130, "", "cancelled", False
    process = subprocess.Popen(
        command,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=provider_environment(),
        start_new_session=True,
    )
    registry.add(process)
    try:
        stdout, stderr = process.communicate(timeout=timeout)
        return process.returncode, stdout, stderr, False
    except subprocess.TimeoutExpired:
        try:
            os.killpg(process.pid, signal.SIGTERM)
            stdout, stderr = process.communicate(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            stdout, stderr = process.communicate()
        return 124, stdout, (stderr + f"\ntimed out after {timeout}s").strip(), True
    finally:
        registry.remove(process)


def build_command(
    task: dict[str, Any], project: dict[str, Any], assets: dict[str, Path], output: Path
) -> tuple[list[str], str, str, str, list[Path]]:
    defaults = project["defaults"]
    ratio = task.get("aspect_ratio", defaults["aspect_ratio"])
    resolution = task.get("resolution", defaults["resolution"])
    quality = task.get("quality", defaults["quality"])
    size = size_for(ratio, resolution)
    image_paths = [assets[item] for item in task["asset_ids"]]
    operation = "edit" if image_paths else "generate"
    command = [
        "codex-imagegen",
        operation,
        "--model",
        defaults["model"],
        "--prompt",
        task["prompt"],
        "--size",
        size,
        "--quality",
        quality,
        "--output-format",
        "png",
        "--out",
        str(output),
    ]
    for image in image_paths:
        command.extend(["--image", str(image)])
    return command, operation, size, quality, image_paths


def execute_task(
    task: dict[str, Any],
    project: dict[str, Any],
    assets: dict[str, Path],
    run_dir: Path,
    *,
    max_attempts: int,
    task_timeout: int,
    registry: ProcessRegistry,
) -> TaskResult:
    task_id = task["id"]
    queued_at = time.monotonic()
    started_at_iso = utc_now()
    attempt_records: list[dict[str, Any]] = []
    rate_limited = False
    largest_retry_after: float | None = None
    output_pixels = task.get("output_pixels")
    final_staged = run_dir / f"{task_id:03d}-{task['output_name']}"
    last_error = "provider failure"
    provider_ms = 0
    postprocess_ms = 0

    for attempt in range(1, max_attempts + 1):
        if registry.cancelled.is_set():
            return TaskResult(
                task_id,
                {
                    "status": "cancelled",
                    "error": "cancelled",
                    "attempt_count": attempt - 1,
                    "retry_count": max(0, attempt - 2),
                    "started_at": started_at_iso,
                    "finished_at": utc_now(),
                    "queued_ms": 0,
                },
            )

        attempt_dir = run_dir / f"task-{task_id:03d}" / f"attempt-{attempt}"
        attempt_dir.mkdir(parents=True, exist_ok=True)
        provider_output = attempt_dir / "provider.png"
        command, operation, size, quality, image_paths = build_command(
            task, project, assets, provider_output
        )
        attempt_started = time.monotonic()
        attempt_started_iso = utc_now()
        returncode, stdout, stderr, timed_out = execute_process(
            command, timeout=task_timeout, registry=registry
        )
        elapsed_ms = round((time.monotonic() - attempt_started) * 1000)
        provider_ms += elapsed_ms
        message = stderr or stdout or "provider returned no output file"
        success = returncode == 0
        if success:
            try:
                validate_image(provider_output)
                post_started = time.monotonic()
                if output_pixels:
                    resize_delivery(
                        provider_output,
                        final_staged,
                        output_pixels["width"],
                        output_pixels["height"],
                    )
                    expected = (output_pixels["width"], output_pixels["height"])
                else:
                    os.replace(provider_output, final_staged)
                    expected = None
                actual = validate_image(final_staged, expected)
                postprocess_ms += round((time.monotonic() - post_started) * 1000)
                attempt_records.append(
                    {
                        "attempt": attempt,
                        "started_at": attempt_started_iso,
                        "finished_at": utc_now(),
                        "duration_ms": elapsed_ms,
                        "returncode": returncode,
                        "status": "success",
                    }
                )
                total_ms = round((time.monotonic() - queued_at) * 1000)
                return TaskResult(
                    task_id,
                    {
                        "status": "generated-awaiting-qa",
                        "output": str(final_staged),
                        "size": size,
                        "delivery_size": f"{actual[0]}x{actual[1]}",
                        "quality": quality,
                        "operation": operation,
                        "image_count": len(image_paths),
                        "qa_status": "pending",
                        "started_at": started_at_iso,
                        "finished_at": utc_now(),
                        "provider_ms": provider_ms,
                        "postprocess_ms": postprocess_ms,
                        "total_ms": total_ms,
                        "attempt_count": attempt,
                        "retry_count": attempt - 1,
                        "attempts": attempt_records,
                        "error": None,
                    },
                    rate_limited,
                    largest_retry_after,
                )
            except (OSError, ValueError, WorkflowError) as exc:
                success = False
                message = str(exc)

        sanitized = sanitize_error(message)
        transient = timed_out or is_transient_failure(message)
        limited = is_rate_limited(message)
        rate_limited = rate_limited or limited
        if limited:
            requested_delay = retry_after_seconds(message)
            if requested_delay is not None:
                largest_retry_after = max(largest_retry_after or 0, requested_delay)
        attempt_records.append(
            {
                "attempt": attempt,
                "started_at": attempt_started_iso,
                "finished_at": utc_now(),
                "duration_ms": elapsed_ms,
                "returncode": returncode,
                "status": "failed",
                "error": sanitized,
            }
        )
        last_error = sanitized
        if not transient or attempt >= max_attempts:
            break
        delay = retry_after_seconds(message)
        if delay is None:
            delay = min(30.0, 2.0**attempt) + random.random()
        time.sleep(delay)

    total_ms = round((time.monotonic() - queued_at) * 1000)
    return TaskResult(
        task_id,
        {
            "status": "failed",
            "error": last_error,
            "qa_status": "pending",
            "started_at": started_at_iso,
            "finished_at": utc_now(),
            "provider_ms": provider_ms,
            "postprocess_ms": postprocess_ms,
            "total_ms": total_ms,
            "attempt_count": len(attempt_records),
            "retry_count": max(0, len(attempt_records) - 1),
            "attempts": attempt_records,
        },
        rate_limited,
        largest_retry_after,
    )


def write_state(
    project_dir: Path,
    project: dict[str, Any],
    plan: dict[str, Any],
    manifest: dict[str, Any],
) -> None:
    with state_lock(project_dir):
        write_json(project_dir / "manifest.json", manifest)
        project["status"] = derive_project_status(plan, manifest)
        write_json(project_dir / "project.json", project)


def main() -> int:
    parser = argparse.ArgumentParser(description="Run an approved ecommerce image plan")
    parser.add_argument("project_dir", type=Path)
    parser.add_argument("--only", help="comma-separated task IDs")
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--provider", choices=["auto", "codex-imagegen"], default="auto")
    parser.add_argument("--concurrency", default="auto", help="auto or an integer from 1 to 20")
    parser.add_argument("--max-concurrency", type=int, default=10)
    parser.add_argument("--max-attempts", type=int, default=2)
    parser.add_argument("--task-timeout", type=int, default=360)
    args = parser.parse_args()

    project_dir = args.project_dir.expanduser().resolve()
    try:
        project, plan = validate_project_dir(project_dir)
        selected = parse_selection(args.only, len(plan["tasks"]))
        if not 1 <= args.max_attempts <= 3:
            raise WorkflowError("--max-attempts must be between 1 and 3")
        if not 60 <= args.task_timeout <= 900:
            raise WorkflowError("--task-timeout must be between 60 and 900 seconds")
    except WorkflowError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    if project["workflow"] == "local-region-replacement":
        print("ERROR: use local_region.py for local-region-replacement", file=sys.stderr)
        return 1
    if not args.dry_run and not plan["approved"]:
        print("ERROR: real generation requires plan.approved=true", file=sys.stderr)
        return 1

    provider = detect_cli_provider()
    if args.provider == "codex-imagegen" and provider is None and not args.dry_run:
        print("ERROR: codex-imagegen is not available in PATH", file=sys.stderr)
        return 1
    if provider is None and not args.dry_run:
        print(
            "ERROR: no CLI provider available; use Codex built-in image generation "
            "and record results with record_result.py",
            file=sys.stderr,
        )
        return 1

    images_dir = project_dir / "images"
    work_dir = project_dir / "work"
    images_dir.mkdir(parents=True, exist_ok=True)
    work_dir.mkdir(parents=True, exist_ok=True)
    assets = {asset["id"]: Path(asset["path"]) for asset in project["assets"]}
    candidates: list[dict[str, Any]] = []
    skipped: list[dict[str, Any]] = []
    for task in plan["tasks"]:
        if selected is not None and task["id"] not in selected:
            continue
        if task.get("enabled", True) is False:
            skipped.append({"task": task, "status": "disabled"})
            continue
        output = images_dir / task["output_name"]
        if output.exists() and output.stat().st_size > 0 and not args.force:
            skipped.append({"task": task, "status": "skipped", "output": str(output)})
            continue
        candidates.append(task)

    try:
        requested_concurrency = resolve_concurrency(
            args.concurrency, len(candidates), args.max_concurrency
        )
    except WorkflowError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1

    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    run_dir = work_dir / "runs" / run_id
    run_started = time.monotonic()
    run_started_iso = utc_now()
    registry = ProcessRegistry()
    interrupted_signal: int | None = None

    def handle_signal(signum, _frame):
        nonlocal interrupted_signal
        interrupted_signal = signum
        registry.cancel()

    old_int = signal.signal(signal.SIGINT, handle_signal)
    old_term = signal.signal(signal.SIGTERM, handle_signal)
    lock_context = nullcontext() if args.dry_run else run_lock(project_dir)

    try:
        with lock_context:
            manifest = load_manifest(project_dir, project)
            manifest["provider"] = provider or "unavailable-dry-run"
            manifest["run"] = {
                "run_id": run_id,
                "started_at": run_started_iso,
                "requested_concurrency": requested_concurrency,
                "actual_peak_concurrency": 0,
                "max_attempts": args.max_attempts,
                "task_timeout_seconds": args.task_timeout,
                "rate_limit_events": 0,
                "concurrency_reductions": [],
                "task_count": len(candidates),
            }
            for item in skipped:
                values = {"status": item["status"], "qa_status": "pending"}
                if item.get("output"):
                    values["output"] = item["output"]
                upsert_result(manifest, item["task"]["id"], values)

            if args.dry_run:
                for task in candidates:
                    defaults = project["defaults"]
                    size = size_for(
                        task.get("aspect_ratio", defaults["aspect_ratio"]),
                        task.get("resolution", defaults["resolution"]),
                    )
                    upsert_result(
                        manifest,
                        task["id"],
                        {
                            "status": "dry-run",
                            "size": size,
                            "quality": task.get("quality", defaults["quality"]),
                            "image_count": len(task["asset_ids"]),
                            "qa_status": "pending",
                        },
                    )
            else:
                project["status"] = "running"
                run_dir.mkdir(parents=True, exist_ok=True)
                remaining = list(candidates)
                current_limit = requested_concurrency
                while remaining and not registry.cancelled.is_set():
                    wave = remaining[:current_limit]
                    remaining = remaining[current_limit:]
                    manifest["run"]["actual_peak_concurrency"] = max(
                        manifest["run"]["actual_peak_concurrency"], len(wave)
                    )
                    for task in wave:
                        upsert_result(
                            manifest,
                            task["id"],
                            {"status": "queued", "queued_at": utc_now(), "qa_status": "pending"},
                        )
                    write_state(project_dir, project, plan, manifest)
                    rate_limited_wave = False
                    retry_after_wave = 0.0
                    with ThreadPoolExecutor(max_workers=len(wave)) as executor:
                        futures = {
                            executor.submit(
                                execute_task,
                                task,
                                project,
                                assets,
                                run_dir,
                                max_attempts=args.max_attempts,
                                task_timeout=args.task_timeout,
                                registry=registry,
                            ): task
                            for task in wave
                        }
                        for future in as_completed(futures):
                            result = future.result()
                            upsert_result(manifest, result.task_id, result.values)
                            if result.rate_limited:
                                rate_limited_wave = True
                                manifest["run"]["rate_limit_events"] += 1
                                retry_after_wave = max(
                                    retry_after_wave, result.retry_after or 0.0
                                )
                    if retry_after_wave:
                        manifest["run"].setdefault("rate_limit_pauses", []).append(
                            {"seconds": retry_after_wave, "at": utc_now()}
                        )
                        time.sleep(retry_after_wave)
                    if rate_limited_wave and remaining:
                        old_limit = current_limit
                        current_limit = 5 if current_limit > 5 else 2 if current_limit > 2 else current_limit
                        if current_limit != old_limit:
                            manifest["run"]["concurrency_reductions"].append(
                                {"from": old_limit, "to": current_limit, "at": utc_now()}
                            )
                    write_state(project_dir, project, plan, manifest)

                if registry.cancelled.is_set():
                    completed_ids = {item.get("task_id") for item in manifest.get("results", [])}
                    for task in remaining:
                        if task["id"] not in completed_ids:
                            upsert_result(
                                manifest,
                                task["id"],
                                {"status": "cancelled", "error": "cancelled"},
                            )

            statuses = [item.get("status") for item in manifest.get("results", [])]
            manifest["run"].update(
                {
                    "finished_at": utc_now(),
                    "wall_ms": round((time.monotonic() - run_started) * 1000),
                    "success_count": sum(status in {"generated-awaiting-qa", "success", "qa-pass"} for status in statuses),
                    "failed_count": sum(status in {"failed", "failed-after-retries"} for status in statuses),
                    "skipped_count": sum(status == "skipped" for status in statuses),
                    "cancelled_count": sum(status == "cancelled" for status in statuses),
                }
            )
            write_state(project_dir, project, plan, manifest)
    except WorkflowError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    finally:
        signal.signal(signal.SIGINT, old_int)
        signal.signal(signal.SIGTERM, old_term)

    print(f"manifest: {project_dir / 'manifest.json'}")
    if interrupted_signal is not None:
        return 128 + interrupted_signal
    failures = sum(
        item.get("status") in {"failed", "failed-after-retries"}
        for item in manifest.get("results", [])
    )
    return 2 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
