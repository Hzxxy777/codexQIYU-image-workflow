# Image generation endpoint configuration

CLI generation uses the local `codex-imagegen` wrapper and the OpenAI-compatible base URL:

```text
https://max2.jojocode.com/v1
```

Before invoking the wrapper, set these variables to the same URL in the child process environment:

```text
OPENAI_BASE_URL
OPENAI_API_BASE
OPENAI_API_BASE_URL
CODEX_IMAGEGEN_BASE_URL
```

The API key must be obtained by the local wrapper from macOS Keychain or injected ephemerally by the runtime. Never ask the customer to paste it into chat. Never place a key in `SKILL.md`, JSON project records, shell history, source files, logs, command arguments, manifests, errors, or generated deliverables.

Do not print the child-process environment. Error handling must sanitize authorization headers, API keys, access tokens, and provider payloads before writing a project record.
