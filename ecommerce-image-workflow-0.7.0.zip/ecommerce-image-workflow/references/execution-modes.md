# Execution modes and concurrent delivery

Every specialist skill reads this reference before creating a plan. If the user
has not already selected a mode, show this exact choice:

```text
请选择本次执行模式：

1. 快速模式
   适合日常出图、批量测试和时间优先的任务。
   提示词和计划完成后立即开始，10 张以内一次性并发生成。
   完成后执行一次批量轻质检，严重失败项最多自动重画 1 次。
   常见 4-6 张套图参考时间：约 2-6 分钟。

2. 专业模式
   适合重点商品、正式上架和质量优先的任务。
   先确认商品事实、视觉方向、分镜和提示词。
   确认后，10 张以内同样一次性并发生成。
   全套集中深度质检，失败项并发重画，质检通过后统一交付。
   无重画时约 3-8 分钟；发生重画时约 6-15 分钟。
   用户确认等待时间另计。

请回复：快速模式 / 专业模式
```

## Mode contract

- `fast` writes `plan.approval_source=automatic-fast-mode`, displays the
  completed plan, and starts without waiting for a second confirmation. It
  uses one batch light QA and allows one QA retry round.
- `professional` writes `plan.approval_source=customer` and waits for prompt,
  storyboard, and full-plan confirmation. It performs deep set-level QA after
  the first generation wave and allows at most two QA retry rounds.
- A mode stated in the user's first message is authoritative. Accept forms
  such as `3 快速`, `手机精修，专业模式`, `fast`, and `professional` without
  asking the same question again.

## Shared executor contract

All multi-task branches call `scripts/run_plan.py --concurrency auto` with the
approved plan. Automatic concurrency is `min(pending_tasks, 10)`: tasks 1-10
start together, and larger plans are dispatched in waves of at most 10. The
same rule applies to fast and professional modes. Exact replication and local
replacement remain one-task operations. Batch resize API generation follows
the same waves; local high-pixel resampling is serialized.

Generation writes each result into `work/runs/<run-id>/` and records
`generated-awaiting-qa`. Nothing is published to `images/` until QA passes.
After a batch QA review, call `record_result.py` once per failed task with
`--qa fail --qa-round N`; this changes the task to `retry-queued`. Re-run only
those task IDs with `run_plan.py --only 2,5 --concurrency auto`. Successful
tasks are never regenerated. On a pass, call `record_result.py` with the
staged output and `--qa pass --qa-round N`; it atomically publishes the final
file and records `qa-pass`.

Technical image decoding and dimension checks happen as each worker finishes.
Visual QA waits for the wave to finish so it can evaluate both individual
images and set consistency. Transient provider failures may be retried by the
executor; permanent input or policy errors are recorded without retry. A 429
honors `Retry-After` and reduces later waves from 10 to 5, then 2. A new run
starts again with the automatic limit of 10.
