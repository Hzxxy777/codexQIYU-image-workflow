# Image quality gate

Inspect a completed generation wave before delivery. Technical decode and size
checks happen as each image finishes; visual review starts after the first wave
is complete so it can judge both single images and set consistency.

## Common checks

- File is non-empty and dimensions match the approved task.
- Output is one complete image, not a collage, grid, or accidental long page.
- Product identity, structure, color, logo, packaging, and accessory count remain
  faithful to the product assets.
- Text is legible, uses the requested language, and contains no extra brand or
  unsupported claim.
- Perspective, contact shadow, reflections, hand interaction, and scene scale are
  physically coherent.
- A multi-image set uses one visual language without repeating the same layout.

## Branch checks

- Detail/main images: each screen has one primary communication goal and the set
  covers the approved selling points.
- Replication: reference layout and style are recognizable, but reference brand
  and product facts do not leak into the result.
- Resize: no stretching, blank bars, cropped critical copy, or missing subject.
- SKU: the correct product and corresponding SKU text appear in each mapped task.
- Local replacement: no selection-box residue or hard seam; original canvas
  dimensions are unchanged.

Fast mode uses the common checks as a light QA gate: identity, structure, count,
color, logo, core text, extra brands, missing subject, and severe canvas errors.
It permits one retry round. Professional mode adds material response, edges,
lighting, perspective, selling-point evidence, text accuracy, composition, and
set consistency; it permits two retry rounds. Mark failures as `retry-queued`,
retry only those task IDs concurrently, and publish a result to `images/` only
after `qa-pass`. Never regenerate a successful batch wholesale unless the user
explicitly requests it.
